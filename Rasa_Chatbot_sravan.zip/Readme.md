### Srakun Foodie Restaurant Bot

An Indian startup named ' Srakun Foodie' wants to build a conversational bot (chatbot) which can help users discover restaurants across several Indian cities. 

The popularity of live chat applications has been growing over the past few years. And as the AI trend keeps rising, chatbots become more a must-have rather than a nice to have part of the business. The increasing demand for chats continues to grow so to keep the customer satisfaction rate high; companies must find ways to cope with the rising volumes of inquiries coming every day to all their communication channels.

## Bot building platforms and frameworks

### Prerequisites

python 3.7.5
rasa 1.10.1

Now let’s set up and develop

#### Setup and installation instructions:

* Download and install anaconda: https://docs.anaconda.com/anaconda/install/ 
* Create a conda virtual environment: https://uoa-eresearch.github.io/eresearch-cookbook/recipe/2014/11/20/conda/
* Install RASA : https://rasa.com/docs/rasa/user-guide/installation/#quick-installation
and other missing dependency(spacy) : https://rasa.com/docs/rasa/user-guide/installation/#dependencies-for-spacy

Go through this quick RASA tutorial: https://rasa.com/docs/rasa/user-guide/rasa-tutorial/ for quick setup.


### Installation instruction(step by step) and seprate env creation:

conda info --envs
conda remove -n rasa --all
conda create -n demo python=3.7
activate demo

## find latest rasa
pip install rasa==2.2.0
## to check the versions are in compact with the rasa and python
pip freeze
## Check 
numpy version is 1.18.5
rasa sdk is having similar version as rasa
## find latest tensorflow
pip install tensorflow== 2.3.1

pip install rasa[spacy]

python -m spacy download en_core_web_md
python -m spacy link en_core_web_md en  

### Project selection  
This definition however often leads to two potential misconceptions.
The biggest misconception that arises is that a chatbot is a bot that converses with a human in the way that another human would converse with a human. Software or even a robot (the digital part of the robot is of course software) that communicates with a human in natural language is not difficult to imagine. Science fiction is full of examples.

While this may be the end goal, this is simply not possible using the current technology. Not only is it not possible, it often leads to unrealistic expectations regarding the chatbot's capabilities and inevitable frustrations when those expectations are not met.

The second misconception is that a chatbot communicates using only text or voice. Actually, chatbots allow users to interact with them via graphical interfaces or graphical widgets, and the trend is in this direction. Many chat platforms including WeChat, Facebook Messenger and Kik allow web views on which developers can create completely customized graphical interfaces.

Chatbots can be used in many different ways, which is the reason why it’s difficult to define exactly what they are. It is actually possible to come up with a chatbot use case for every single business or industry, in the same way, that every business or industry can use a website or app.	
Literally any task you can do delegate to Chatbot. A couple of things you can definitely do is training chatbot to handle FAQs, Basic flow handling where it can help the user to view,  purchase, or track something, feedback collection or notification. 

All the above examples of chatbots could allow human agents to get involved in the conversation if necessary, perhaps as a premium service.

### Documentation/Design

Detailed conversation design based on a defined scope is the first thing you should do before you head to development. If you are completely new to it and don’t know where to start then we recommend this article: [How to design a robust chatbot interaction](https://uxdesign.cc/how-to-design-a-robust-chatbot-interaction-8bb6dfae34fb?gi=b521852a15a6)

Just like human chatbot needs to have personality, persona, and tone too(Aren't chatbot supposed to behave like a human 😜) Read more about chatbot personality here : [Why AI And Chatbots Need Personality](https://www.linkedin.com/pulse/why-ai-chatbots-need-personality-bernard-marr/?trackingId=if7XdV00TsqtxL0WwiJfAw%3D%3D)

There are a couple of online tools you can use to layout chatbot's conversation design.  
[moqups](https://moqups.com/)  
[draw.io](https://www.draw.io/)

Read this thread to find out more apps/software: https://news.chatbotsmagazine.com/t/tool-method-to-design-conversation-diagram/915/20

In this tutorial, we will build a simple to complex restaurant bot step by step with the objective of exploring all awesome features of RASA and make a personal assistant for yourself or for your business. 
We assume you have gone through the chatbot introduction,  various types of the chatbot, how to select chatbot as a project, It’s design practice, etc. 
If not then we highly recommend that you read the README of this section.

In this phase, we will be building a simple flow where users can search restaurants on bot through Zomato API based location and cuisine. 
As per the best design practice, the bot should welcome the user with the greeting and let the user know what bot can do. 
If user request matches with in-flow intents and if there are no or missing entities in the utterance then bot should ask required entities (cuisine and location in this phase) to complete the action (search restaurant from Zomato API). 
Here will train our model to extract cuisine and will use Bing map API to extract location as it’s impossible to train every damn location. 

To hit Zomato API with location we need entity_id, entity_type, lat and long which will get from [/location](https://developers.zomato.com/documentation#!/location/locations) and for cuisine, we need cuisine_id which you will get from [/cuisines](https://developers.zomato.com/documentation#!/common/cuisines)
Once we have all the details we can hit [/search](https://developers.zomato.com/documentation#!/restaurant/search) which is the main and final endpoint where you will get restaurant details. By default, you will get 20 top matched restaurants. We kept count as 5. Play around with Zomato API to get comfortable with it: https://developers.zomato.com/documentation

#### Zomato API
To start with, we will need an API key from Zomato, so navigate to [Zomato](https://developers.zomato.com/api) and ‘request an API key’.  
On being prompted, we may either sign up on Zomato or ‘Continue with Google’. After we have completed the sign up, we should receive the API key

#### Microsoft Bing Maps REST API
To use the Bing Maps REST API, we will need ‘Bing Maps Key’. Therefore, navigate [here](https://docs.microsoft.com/en-us/bingmaps/getting-started/bing-maps-dev-center-help/getting-a-bing-maps-key) and then click on ‘Bing Maps Key’ hyperlink. After we have signed up (if we do not have an account on Microsoft) and provided our basic information, we can create a key. Bing Maps API provides a ‘basic’ key, by default (i.e. it can be specified directly in the request header, no need of OAuth complexity).  
After the key has been created we can see/ copy it by clicking on ‘My Account’ -> ‘My Keys’.  
Now, we have what we needed to start with. Let’s dive in to Postman and get the stuff working.

Look at the below self-explanatory state diagram which shows conversation flow with all required states.
![Conversation diagram](https://drive.google.com/open?id=0B8VyXj56P9UiOVpLX2RNR1hlb3J4UE1jdnh0Z3ExeDFCWkRJ)

### What is Rasa?
[Rasa](https://rasa.com/docs/rasa/) is an open-source machine learning framework for building [contextual AI assistants and chatbots](https://blog.rasa.com/level-3-contextual-assistants-beyond-answering-simple-questions/).  
To make complete AI-based chatbot it has to handle two things: 

* Understanding the user’s message which is done through Rasa [NLU](https://rasa.com/docs/rasa/nlu/about/).
* The bot should be able to carry dialogue with context which is done by Rasa [Core](https://rasa.com/docs/rasa/core/about/).


1. Tokenization: 
We read and understand the sentence word by word, right? Similarly, tokenizer will break the sentence into words(called word tokenizer).   
For more information on RASA supported tokenizer refer: https://rasa.com/docs/rasa/nlu/components/#tokenizers

2.  Featurizer: 
We infer meaning by words and when all words are combined in a sentence then we infer the meaning of the sentence with context, right? Similarly, tokenized words are used as features to the post components of the pipeline. These features are has meaning of the word(mathematically) which is called Embeddings. Get to know more about word embedding here. Embedding comes in below two flavors.   
    ###### Embedding:  
	1. Pre-trained:   
Here word embeddings are already trained on huge text datasets with various state-of-the-art architecture. Popular word embeddings are XLNet, BERT, Glove, etc. We can use word embedding as it is in our NLP pipeline when we don’t have much training data. This technique is called as transfer learning.  
	2. From scratch:   
When pre-trained does not work well because it might have trained on your domain-specific then we can train our own word embedding from scratch. It is recommended when you have sufficient training samples.   
RASA supports both types of word embedding. Refer this for more: https://rasa.com/docs/rasa/nlu/choosing-a-pipeline/#a-longer-answer  
For more information on RASA supported featurizers refer:  https://rasa.com/docs/rasa/nlu/components/#featurizers    
     3. Count vectorizer:  
       You can convert a sentence into features using a bag of words. Where you can have unigram, bi-gram, tri-gram.   
Check this for more information: https://rasa.com/docs/rasa/nlu/components/#countvectorsfeaturizer  
> Another interesting tweak is to increase the number of n-grams, which is 1 by default. By using a max_ngram of 2, you will create additional features for each couple of consecutive words. For example, if you want to recognize “I'm happy” and “I'm not happy” as different intents, it helps to have not happy as a feature.

3. Entity extraction   
These are a chunk of information we extract from sentences to complete the action. For example when we say `I need to book restaurant`. Here the intent is “search_restaurant" and to fetch information we need to know location i.e Hyderabad couple more entities like cusines and price etc.

Once the intent is identified and all entity is extracted then we can complete the action by calling the required API.

Read more about entity extraction here: https://rasa.com/docs/rasa/nlu/entity-extraction/
 
4. Classifier  
Now you know the meaning(features) of the sentence(words through tokenization). It’s time to classify to its appropriate category. For e.g `what kind of cuisine would you like?` should classify to cusine type. All this is done by using Machine learning or Deep learning classifier.  
Read more about supported RASA classifier here: https://rasa.com/docs/rasa/nlu/components/#intent-classifiers  
For more information about NLU pipeline and it’s component refer: https://rasa.com/docs/rasa/nlu/choosing-a-pipeline/ & https://rasa.com/docs/rasa/nlu/components/

Also read this in-depth information about NLU here: https://blog.rasa.com/rasa-nlu-in-depth-part-1-intent-classification/ 
 
 with this knowledge we will be building the bot with following yamal files:

## Rasa config
https://rasa.com/docs/rasa/tuning-your-model/
https://rasa.com/docs/rasa/policies

language: "en"
pipeline:
  - name: SpacyNLP
  - name: SpacyTokenizer
  - name: SpacyFeaturizer
  - name: RegexFeaturizer
  - name: LexicalSyntacticFeaturizer
  - name: CountVectorsFeaturizer
  - name: CountVectorsFeaturizer
    analyzer: "char_wb"
    min_ngram: 1
    max_ngram: 4
  - name: DIETClassifier
    epochs: 100
  - name: EntitySynonymMapper
  - name: ResponseSelector
    epochs: 100
policies:
  - name: MemoizationPolicy
  - name: TEDPolicy
    max_history: 5
    epochs: 200
  - name: RulePolicy


### rasa domain
actions:
- action_search_restaurants
- check_location
- utter_ask_cuisine
- utter_ask_howcanhelp
- utter_ask_location
- utter_default
- utter_goodbye
- utter_greet
entities:
- cuisine
- location
- people
- price
intents:
- greet
- restaurant_search
- affirm
- goodbye
- stop.
responses:
  utter_ask_cuisine:
  - buttons:
    - payload: Chinese
      title: Chinese
    - payload: Italian
      title: Italian
    - payload: South Indian
      title: South Indian
    - payload: North Indian
      title: North Indian
    text: what kind of cuisine would you like?
  utter_ask_howcanhelp:
  - text: how can I help you?
  utter_ask_location:
  - text: In what location?
  utter_default:
  - text: i cannot understand
  utter_goodbye:
  - text: goodbye :(
  - text: Bye-bye
  utter_greet:
  - text: hey there! How may i help you
  - text: Hi, How can I help you!
  - text: Hey, How is it going How May I help you Today
session_config:
  carry_over_slots_to_new_session: true
  session_expiration_time: 0
slots:
  cuisine:
    type: text
  location:
    type: text
  check_op:
    type: bool

Here Interpreter is part of NLU and Tracker, policy and action are part of Core.
* The message is passed to an Interpreter, which converts it into a dictionary including the original text, the intent, and any entities that were found.
* The Tracker is the object which keeps track of the conversation state. It receives the info that a new message has come in. Know more about it here: https://rasa.com/docs/rasa/api/tracker-stores/
* The policy receives the current state of the tracker, chooses the next action which is logged by the tracker and response is sent to the user. There are different policies to choose from.   
You will get more information here: https://rasa.com/docs/rasa/core/policies/#policies  
Along with policy “slots” which act as bot’s memory(context). It also influences how the dialogue progresses. Read more about slots here: https://rasa.com/docs/rasa/core/slots/

These settings are part of config.yml (Think this file as the brain of chatbot :P)

Now we have all the ingredients ready to build a chatbot.
* Defining the scope of the bot ✅
* Exploring Zomato API ✅
* Understand RASA and its components ✅

## train nlu
rasa train nlu

## test nlu
rasa shell nlu


Core policy
Till now we saw how chatbot understands the user sentence and classifies to proper intent and extract entities. 
But we humans follow natural conversation where we remember context and reply accordingly. Otherwise, it will look something like this. Frustrating 😠 isn't it?
![Conversation diagram](https://lh3.googleusercontent.com/ymb8CbApXrzsT-tvxHVqew4G5sNulGi7v3TWGbAS29WSVQK_bSf4wGzV9Yzf4V8FlGul2nSEJK-F14MHvnuWlYq04TNGMYaPQNqXptip)

So how does rasa handles all this? It is done through various elements of the RASA. Let’s look at the architecture of the RASA.
![Conversation diagram](https://lh4.googleusercontent.com/vglDus-TNUadCP-JJvCHOGwUkn4NdTD6balsubtO-Q9CO6nlR1u1x8egD_dWZSNSmf98ArqjCYVhCxZAfZ_RrJOM-Dx1cn56N5oAiWoPMc35LYY2DS0uVyz1W5DsIQzkfU23Bcob)


So far so good? We have gone through the psychology of the bot. Now it’s time to look at the environment of the chatbot which will help it to learn. 
Just like a growing baby, he/she learn from whatever is experienced. Similarly will need to train a chatbot with right training data.   
Which comes in the form of text utterances part of defined intent with the tagged entity for training NLU and as a story(like a conversation) to train RASA core.   
Read more about training data for NLU here: https://rasa.com/docs/rasa/nlu/training-data-format/ and for stories here: https://rasa.com/docs/rasa/core/stories/

Execute command "/stop" to close shell


## start action server
rasa run actions

## create new data
rasa interactive

## rule-based action prediction
https://rasa.com/docs/rasa/rules

##mail send
https://www.tutorialspoint.com/send-mail-from-your-gmail-account-using-python


YOUTUBE VIDEO LINK: https://youtu.be/N2VwOTddrD0


## Authors

* **Sravan Sreereddy**
* **Kunal Rajan Gaikwad**


 

